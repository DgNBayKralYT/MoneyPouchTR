<?php

namespace MoneyPouch;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\item\Item;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\scheduler\PluginTask;
use pocketmine\utils\TextFormat as TF;

use onebone\economyapi\EconomyAPI;

class Main extends PluginBase implements Listener {
	
	public function onEnable() {
		
		$this->getServer()->getLogger()->notice("
                                                 █████████
    ███████                        ███▒▒▒▒▒▒▒▒███
    █▒▒▒▒▒▒█                ███▒▒▒▒▒▒▒▒▒▒▒▒▒███
      █▒▒▒▒▒▒█         ██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒██
        █▒▒▒▒▒█       ██▒▒▒▒▒██▒▒▒▒▒▒██▒▒▒▒▒███
          █▒▒▒█       █▒▒▒▒▒▒████▒▒▒▒████▒▒▒▒▒▒██
      █████████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒██
      █▒▒▒▒▒▒▒▒▒▒▒▒█▒▒▒▒▒▒▒▒▒█▒▒▒▒▒▒▒▒▒▒▒██
  ██▒▒▒▒▒▒▒▒▒▒▒▒▒█▒▒▒██▒▒▒▒▒▒▒▒▒▒██▒▒▒▒██
██▒▒▒███████████▒▒▒▒▒██▒▒▒▒▒▒▒▒██▒▒▒▒▒██
█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒█▒▒▒▒▒▒████████▒▒▒▒▒▒▒██
██▒▒▒▒▒▒▒▒▒▒▒▒▒▒█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒██
  █▒▒▒███████████▒▒▒▒ DgNBayKralYT ▒▒▒██
  ██▒▒▒▒▒▒▒▒▒▒████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒█
    ████████████       █████████████████         §aPlugin Aktif !");
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		
	}
	
	public function onCommand(CommandSender $sender, Command $command, string $label, array $args) : bool {
		
		if(strtolower($command->getName()) === "parakasa") {
			
			if(count($args) < 2) {
			
				$sender->sendMessage(TF::BOLD . TF::DARK_GRAY . "" . TF::GOLD . "" . TF::DARK_GRAY . "" . TF::RESET . TF::GRAY . "§cDikkat: §f/parakasa *Oyuncu* *Kasa Sv*");
				return true;
			 
			}
			if($sender->hasPermission("parakasa.command.give") || $sender->isOp()){
				
				if(isset($args[0])) {
				
					$player = $sender->getServer()->getPlayer($args[0]);
					
					if(isset($args[1])) {
						
						switch($args[1]) {
							
							case 1:
							
							$tier1 = Item::get(Item::ENDER_CHEST, 101, 1);
							$tier1->setCustomName(TF::RESET . TF::BOLD . TF::LIGHT_PURPLE . "Para Kasa" . TF::RESET . TF::GRAY . " Yere Tıkla !" . PHP_EOL . PHP_EOL . 
							TF::DARK_GRAY . " *" . TF::AQUA . " §aKasa Sv: " . TF::GRAY . "§f1" . PHP_EOL .
							TF::DARK_GRAY . " *" . TF::AQUA . " §bPara Aralığı: " . TF::GRAY . "§f10,000 §6TL§7 - §f25,000 §6TL");
							
							$player->getInventory()->addItem($tier1);
							
							break;
							
							case 2:
							
							$tier2 = Item::get(Item::ENDER_CHEST, 102, 1);
							$tier2->setCustomName(TF::RESET . TF::BOLD . TF::LIGHT_PURPLE . "Para Kasa" . TF::RESET . TF::GRAY . " Yere Tıkla !" . PHP_EOL . PHP_EOL . 
							TF::DARK_GRAY . " *" . TF::AQUA . " §aKasa Sv: " . TF::GRAY . "§f2" . PHP_EOL .
							TF::DARK_GRAY . " *" . TF::AQUA . " §bPara Aralığı: " . TF::GRAY . "§f25,000 §6TL§7 - §f50,000 §6TL");
							
							$player->getInventory()->addItem($tier2);
							
							break;
							
							case 3:
							
							$tier3 = Item::get(Item::ENDER_CHEST, 103, 1);
							$tier3->setCustomName(TF::RESET . TF::BOLD . TF::LIGHT_PURPLE . "Para Kasa" . TF::RESET . TF::GRAY . " Yere Tıkla !" . PHP_EOL . PHP_EOL . 
							TF::DARK_GRAY . " *" . TF::AQUA . " §aKasa Sv: " . TF::GRAY . "§f3" . PHP_EOL .
							TF::DARK_GRAY . " *" . TF::AQUA . " §bPara Aralığı: " . TF::GRAY . "§f50,000 §6TL§7 - §f100,000 §6TL");
							
							$player->getInventory()->addItem($tier3);
							
							break;
							
							case 4:
							
							$tier4 = Item::get(Item::ENDER_CHEST, 104, 1);
							$tier4->setCustomName(TF::RESET . TF::BOLD . TF::LIGHT_PURPLE . "Para Kasa" . TF::RESET . TF::GRAY . " Yere Tıkla !" . PHP_EOL . PHP_EOL . 
							TF::DARK_GRAY . " *" . TF::AQUA . " §aKasa Sv: " . TF::GRAY . "§f4" . PHP_EOL .
							TF::DARK_GRAY . " *" . TF::AQUA . " §bPara Aralığı: " . TF::GRAY . "§f100,000 §6TL§7 - §f500,000 §6TL");
							
							$player->getInventory()->addItem($tier4);
							
							break;
							
							case 5:
							
							$tier5 = Item::get(Item::ENDER_CHEST, 105, 1);
							$tier5->setCustomName(TF::BOLD . TF::LIGHT_PURPLE . "Para Kasa" . TF::RESET . TF::GRAY . " Yere Tıkla !" . PHP_EOL . PHP_EOL . 
							TF::DARK_GRAY . " *" . TF::AQUA . " §aKasa Sv: " . TF::GRAY . "§f5" . PHP_EOL .
							TF::DARK_GRAY . " *" . TF::AQUA . " §bPara Aralığı: " . TF::GRAY . "§f500,000 §6TL §7- §f1,000,000 §6TL");
							
							$player->getInventory()->addItem($tier5);
							
							break;
							
						}
					}
				}
			}
			
			if(!$sender->hasPermission("parakasa.command.give")) {
				
				$sender->sendMessage(TF::BOLD . TF::DARK_GRAY . "" . TF::RED . "" . TF::DARK_GRAY . " " . TF::RESET . TF::GRAY . "§cBu Komutu Kullanmaya Yetkiniz Yok!");
				
			}
			
			else {
				
				$sender->sendMessage(TF::BOLD . TF::DARK_GRAY . "" . TF::GOLD . "" . TF::DARK_GRAY . " " . TF::RESET . TF::GRAY . "§a1 Adet Para Kasa!");
				
			}
		}
		
		return true;
		
	}
	
	public function onInteract(PlayerInteractEvent $event) {
		
		$player = $event->getPlayer();
		
		if($event->getItem()->getId() === 130) {
		
			$damage = $event->getItem()->getDamage();
			
			switch($damage) {
				
				case 101:
				
				$tier1 = Item::get(Item::ENDER_CHEST, 101, 1);
				$tier1win = rand(10000, 25000);
				
				EconomyAPI::getInstance()->addMoney($player, $tier1win);
				
				$player->addTitle(TF::BOLD . TF::DARK_GRAY . "" . TF::GREEN . "☆" . TF::DARK_GRAY . "" . TF::RESET . TF::GRAY . "Çıkan Para:", TF::BOLD . TF::LIGHT_PURPLE . "" . $tier1win);
				$player->getInventory()->removeItem($tier1);
				
				break;
				
				case 102:
				
				$tier2 = Item::get(Item::ENDER_CHEST, 102, 1);
				$tier2win = rand(25000, 50000);
				
				EconomyAPI::getInstance()->addMoney($player, $tier2win);
				
				$player->addTitle(TF::BOLD . TF::DARK_GRAY . "" . TF::GREEN . "☆" . TF::DARK_GRAY . "" . TF::RESET . TF::GRAY . "Çıkan Para:", TF::BOLD . TF::LIGHT_PURPLE . "" . $tier2win);
				$player->getInventory()->removeItem($tier2);
				
				break;
				
				case 103:
				
				$tier3 = Item::get(Item::ENDER_CHEST, 103, 1);
				$tier3win = rand(50000, 100000);
				
				EconomyAPI::getInstance()->addMoney($player, $tier3win);
				
				$player->addTitle(TF::BOLD . TF::DARK_GRAY . "" . TF::GREEN . "☆" . TF::DARK_GRAY . "" . TF::RESET . TF::GRAY . "Çıkan Para:", TF::BOLD . TF::LIGHT_PURPLE . "" . $tier3win);
				$player->getInventory()->removeItem($tier3);
				
				break;
				
				case 104:
				
				$tier4 = Item::get(Item::ENDER_CHEST, 104, 1);
				$tier4win = rand(100000, 500000);
				
				EconomyAPI::getInstance()->addMoney($player, $tier4win);
				
				$player->addTitle(TF::BOLD . TF::DARK_GRAY . "" . TF::GREEN . "☆" . TF::DARK_GRAY . "" . TF::RESET . TF::GRAY . "Çıkan Para:", TF::BOLD . TF::LIGHT_PURPLE . "" . $tier4win);
				$player->getInventory()->removeItem($tier4);
				
				break;
				
				case 105:
				
				$tier5 = Item::get(Item::ENDER_CHEST, 105, 1);
				$tier5win = rand(500000, 1000000);
				
				EconomyAPI::getInstance()->addMoney($player, $tier5win);
				
				$player->addTitle(TF::BOLD . TF::DARK_GRAY . "" . TF::GREEN . "☆" . TF::DARK_GRAY . "" . TF::RESET . TF::GRAY . "Çıkan Para:", TF::BOLD . TF::LIGHT_PURPLE . "" . $tier5win);
				$player->getInventory()->removeItem($tier5);
				
				break;
				
			}
		}
	}
	
	public function onPlace(BlockPlaceEvent $event) {
		
		if($event->getItem()->getId() == 130) {
			
			$damage = $event->getItem()->getDamage();
			
			if($damage === 101 || $damage === 102 || $damage === 103 || $damage === 104 || $damage === 105) {
				
				$event->setCancelled();
				
			}
		}
	}
}
